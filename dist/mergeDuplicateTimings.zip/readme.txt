mergeDuplicateTimings.js - 1.2.0
https://github.com/bob-ross27/toonboom

Description: Iterate across all frames of selected read node, changing exposure to the first detected instance of each timing. This assumes each duplicate image is identical, likely computer generated images.

Usage: Click one or more read nodes and click the icon to run the script.