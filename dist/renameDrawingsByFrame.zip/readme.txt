renameDrawingsByFrame.js - 1.0.1
https://github.com/bob-ross27/toonboom

Description: Rename draiwngs to their first exposed frame. This roughly emulates the included rename to frame function, but does it across selected nodes instead of on selected frames in a column.

Usage: Click one or more read nodes and click the icon to run the script.